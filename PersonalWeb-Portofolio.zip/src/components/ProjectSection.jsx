import { useState } from 'react';
import { ExternalLink } from 'lucide-react';

// Import gambar-gambar project
import ratuBogaOrderImg from '../assets/images/ratu-boga-order.png';
import travlocImg from '../assets/images/travloc.png';
import academicManagerImg from '../assets/images/travloc.png';
import trubersImg from '../assets/images/travloc.png';
import wajoImg from '../assets/images/travloc.png';
import portfolioV3Img from '../assets/images/travloc.png';

const ProjectSection = () => {
  const [hoveredProject, setHoveredProject] = useState(null);

  const projects = [
    {
      id: 'ratu-boga-order',
      title: 'RM. Ratu Boga QR Order System',
      subtitle: 'Fullstack Food Ordering System',
      description:
        'End-to-end web-based self-ordering system using QR codes with real-time order processing via WebSocket.',
      tags: ['React', 'Express', 'Node.js', 'WebSocket'],
      color: '#FF6B6B',
      accentColor: 'bg-[#FF6B6B]',
      projectLink: '/projects/ratu-boga-order',
      image: ratuBogaOrderImg,
    },
    {
      id: 'trubers',
      title: 'TRUBERS',
      subtitle: 'Trust Builder Telkomsel Sulawesi',
      description:
        'Content evaluation and leaderboard system developed during Telkomsel internship, including social media data scraping and admin dashboard.',
      tags: ['React', 'Express', 'JavaScript', 'Web Scraping'],
      color: '#4ECDC4',
      accentColor: 'bg-[#4ECDC4]',
      projectLink: '/projects/trubers',
      image: trubersImg,
    },
    {
      id: 'wajo',
      title: 'WAJO',
      subtitle: 'WhatsApp Jadwal Otomatis',
      description:
        'Automated WhatsApp scheduling and broadcast system built to help communities manage scheduled communications efficiently.',
      tags: ['React', 'Express', 'JavaScript'],
      color: '#06D6A0',
      accentColor: 'bg-[#06D6A0]',
      projectLink: '/projects/wajo',
      image: wajoImg,
    },
    {
      id: 'travloc',
      title: 'Travloc',
      subtitle: 'Tourism & UMKM Promotion Platform',
      description:
        'Capstone project for Baparekraf Digital Talent 2024 focusing on UI/UX design and front-end development.',
      tags: ['HTML', 'CSS', 'JavaScript', 'Figma'],
      color: '#FFD166',
      accentColor: 'bg-[#FFD166]',
      projectLink: '/projects/travloc',
      image: travlocImg,
    },
    {
      id: 'academic-manager',
      title: 'SI-FA Academic Information System',
      subtitle: 'Faculty Information System',
      description:
        'UI/UX design project for Faculty of Pharmacy Universitas Hasanuddin, emphasizing consistency and usability.',
      tags: ['UI/UX', 'Figma', 'Design System'],
      color: '#9D4EDD',
      accentColor: 'bg-[#9D4EDD]',
      projectLink: '/projects/academic-manager',
      image: academicManagerImg,
    },
    {
      id: 'portfolio-v3',
      title: 'Personal Portfolio V3',
      subtitle: 'Modern Developer Portfolio',
      description:
        'Personal portfolio website built with React and Tailwind CSS to showcase projects and professional experience.',
      tags: ['React', 'Tailwind', 'Vite'],
      color: '#FF9E6D',
      accentColor: 'bg-[#FF9E6D]',
      projectLink: '/projects/portfolio-v3',
      image: portfolioV3Img,
    },
  ];


  const handleProjectClick = (projectLink) => {
    console.log('Navigating to:', projectLink);
    // Implement your navigation logic here
  };

  return (
    <section className='min-h-screen py-16 px-5 md:px-12 lg:px-13 font-alumni'>
      <div className='font-alumni pb-10 md:pb-24 lg:pb-20'>
        <h2
          className='font-alumni text-6xl text-black font-medium leading-[75%]
                      md:text-9xl
                      lg:text-[10rem]'
        >
          Projects
        </h2>
      </div>

      {/* Grid Container */}
      <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4'>
        {projects.map((project) => (
          <a
            key={project.id}
            href={project.projectLink}
            onClick={(e) => {
              e.preventDefault();
              handleProjectClick(project.projectLink);
            }}
            className='relative block overflow-hidden bg-gray-900 aspect-[4/3] rounded-none transition-all duration-500 hover:scale-[1.02] group'
            onMouseEnter={() => setHoveredProject(project.id)}
            onMouseLeave={() => setHoveredProject(null)}
          >
            {/* Project Image Container */}
            <div className='absolute inset-0 transition-all duration-500 overflow-hidden'>
              {/* Gambar dengan filter monokrom saat normal */}
              <img
                src={project.image}
                alt={project.title}
                className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ${
                  hoveredProject === project.id
                    ? 'opacity-100 grayscale scale-105'
                    : 'grayscale-0 opacity-100'
                }`}
              />

              {/* Overlay warna saat hover */}
              <div
                className={`absolute inset-0 transition-all duration-500 ${
                  hoveredProject === project.id
                    ? `bg-gradient-to-br from-[#7b7b7b] to-[#ffffff] opacity-80`
                    : 'opacity-0'
                }`}
              ></div>
            </div>

            {/* Content Overlay - HANYA muncul saat hover */}
            <div
              className={`absolute inset-0 p-6 flex flex-col justify-between transition-all duration-500 ${
                hoveredProject === project.id ? 'opacity-100' : 'opacity-0'
              }`}
            >
              {/* Top Section - Title */}
              <div className='transform transition-all duration-500'>
                <h3 className='text-3xl md:text-4xl font-medium text-black mb-2'>
                  {project.title}
                </h3>
                <p className='text-black text-lg'>{project.subtitle}</p>
              </div>

              {/* Bottom Section - View Project Button */}
              <div className='transform transition-all duration-500'>
                <div className='flex items-center justify-between'>
                  <span className='text-black text-xl font-medium flex items-center gap-2'>
                    View Project
                    <ExternalLink
                      size={20}
                      className='ml-1 transition-transform duration-300 group-hover:translate-x-1'
                    />
                  </span>

                  {/* Tags */}
                  <div className='flex gap-1'>
                    {project.tags.slice(0, 2).map((tag, index) => (
                      <span
                        key={index}
                        className='px-2 py-1 bg-black/20 backdrop-blur-sm text-black text-xs rounded'
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Project ID Badge - HANYA muncul saat hover */}
            <div
              className={`absolute top-4 right-4 px-3 py-1 text-sm transition-all duration-500 ${
                hoveredProject === project.id
                  ? 'bg-white/20 backdrop-blur-sm text-white opacity-100'
                  : 'opacity-0'
              } rounded`}
            >
              {projects.indexOf(project) + 1 < 10
                ? `0${projects.indexOf(project) + 1}`
                : projects.indexOf(project) + 1}
            </div>

            {/* Hover Border Effect */}
            <div
              className={`absolute inset-0 border-2 transition-all duration-500 ${
                hoveredProject === project.id
                  ? 'border-white/30'
                  : 'border-transparent'
              }`}
            ></div>
          </a>
        ))}
      </div>

      {/* View All Projects Link */}
      <div className='text-center mt-12'>
        <a
          href='/projects'
          onClick={(e) => {
            e.preventDefault();
            handleProjectClick('/projects');
          }}
          className='inline-flex items-center text-2xl text-black font-medium hover:text-crayola transition-colors duration-300 no-underline'
        >
          View all projects
          <ExternalLink size={20} className='ml-2' />
        </a>
      </div>
    </section>
  );
};

export default ProjectSection;